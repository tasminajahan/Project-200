-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2018 at 05:05 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `staffinformation`
--

-- --------------------------------------------------------

--
-- Table structure for table `agm_f`
--

CREATE TABLE `agm_f` (
  `Id` int(11) NOT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `Position` varchar(15) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Salary` decimal(8,2) DEFAULT NULL,
  `Workingtime` varchar(15) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agm_f`
--

INSERT INTO `agm_f` (`Id`, `Name`, `Position`, `Age`, `Salary`, `Workingtime`, `Gender`) VALUES
(120, 'Rukun Nahar', 'BS', 34, '32000.00', '8 Hour', 'Female'),
(121, 'Mhabubul Alam', 'AC', 38, '55000.00', '8 Hour', 'Male'),
(122, 'Juli Akter', 'A_AC', 32, '50000.00', '8 Hour', 'Female'),
(123, 'Athik Mia ', 'A_AC', 40, '48000.00', '8 Hour', 'Male'),
(124, 'Shain Mia', 'A_AC', 41, '47000.00', '8 Hour', 'Male'),
(125, 'Horitush Paul', 'A_AC', 46, '42000.00', '8 Hour', 'Male'),
(126, 'Kabir Ahmed', 'A_AC', 44, '42000.00', '8 Hour', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `agm_gs`
--

CREATE TABLE `agm_gs` (
  `Id` int(11) NOT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `Position` varchar(15) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Salary` decimal(8,2) DEFAULT NULL,
  `Workingtime` varchar(15) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agm_gs`
--

INSERT INTO `agm_gs` (`Id`, `Name`, `Position`, `Age`, `Salary`, `Workingtime`, `Gender`) VALUES
(108, 'Amir Husan', 'AEC', 38, '50000.00', '8 Hour', 'Male'),
(109, 'Gulzar Husan', 'AGC', 42, '50000.00', '8 Hour', 'Male'),
(110, 'Billal Husan', 'AGC', 44, '49000.00', '8 Hour', 'Male'),
(111, 'Indira Dash', 'DEO', 38, '35000.00', '8 Hour', 'Female'),
(112, 'Husneara Begum', 'DEO', 35, '32000.00', '8 Hour', 'Female'),
(113, 'Shopna Dey', 'DEO', 32, '31000.00', '8 Hour', 'Female'),
(114, 'Shahina Begum', 'DEO', 34, '30000.00', '8 Hour', 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `agm_ms`
--

CREATE TABLE `agm_ms` (
  `Id` int(11) NOT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `Position` varchar(15) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Salary` decimal(8,2) DEFAULT NULL,
  `Workingtime` varchar(15) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agm_ms`
--

INSERT INTO `agm_ms` (`Id`, `Name`, `Position`, `Age`, `Salary`, `Workingtime`, `Gender`) VALUES
(115, 'Mothin Mia', 'PUC', 37, '48000.00', '8 Hour', 'Male'),
(116, 'Khaled Husan', 'MSC', 40, '48000.00', '8 Hour', 'Male'),
(117, 'Monir Hussain', 'WI', 44, '35000.00', '8 Hour', 'Male'),
(118, 'Khadir Mia', 'WI', 49, '35000.00', '8 Hour', 'Male'),
(119, 'Shafirul Islam', 'WI', 50, '34000.00', '8 Hour', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `agm_om`
--

CREATE TABLE `agm_om` (
  `Id` int(11) NOT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `Position` varchar(15) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Salary` decimal(8,2) DEFAULT NULL,
  `Workingtime` varchar(15) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agm_om`
--

INSERT INTO `agm_om` (`Id`, `Name`, `Position`, `Age`, `Salary`, `Workingtime`, `Gender`) VALUES
(127, 'Abdus Salam', 'JE', 48, '56000.00', '8 Hour', 'Male'),
(128, 'Monirul Islam', 'A_JE', 47, '45000.00', '8 Hour', 'Male'),
(129, 'Kabir Islam', 'LT', 43, '43000.00', '8 Hour', 'Male'),
(130, 'Tazuddin Ahmed', 'LT', 47, '44000.00', '8 Hour', 'Male'),
(131, 'Rezaul Karim', 'LT', 46, '44000.00', '8 Hour', 'Male'),
(132, 'Sulaiman Ahmed', 'LM_1', 38, '38000.00', '8 Hour', 'Male'),
(133, 'Zohirul Islam', 'LM_1', 41, '38000.00', '8 Hour', 'Male'),
(134, 'Subir Talukder', 'LM_1', 43, '35000.00', '8 Hour', 'Male'),
(135, 'Gupal Shokar', 'LM_1', 42, '35000.00', '8 Hour', 'Male'),
(136, 'Rintu Ch.', 'LM_1', 39, '35000.00', '8 Hour', 'Male'),
(137, 'Sharif Ahmed', 'LM_2', 35, '30000.00', '8 Hour', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `staff_details`
--

CREATE TABLE `staff_details` (
  `Id` int(11) NOT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Position` varchar(15) DEFAULT NULL,
  `Salary` decimal(8,2) DEFAULT NULL,
  `Workingtime` varchar(15) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_details`
--

INSERT INTO `staff_details` (`Id`, `Name`, `Age`, `Position`, `Salary`, `Workingtime`, `Gender`) VALUES
(101, 'E.Mhabubul alam', 58, 'GM', '150000.00', '8 Hour', 'Male'),
(102, 'E.Shahin Kabir', 50, 'DGM_TC', '80000.00', '8 Hour', 'Male'),
(103, 'Zhohirul Islam', 45, 'DGM', '77000.00', '8 Hour', 'Male'),
(104, 'Clinton Datta', 40, 'AGM_GS', '65000.00', '8 Hour', 'Male'),
(105, 'Milan Kanti Ch.', 40, 'AGM_MS', '65000.00', '8 Hour', 'Male'),
(106, 'Abul Husan', 43, 'AGM_F', '68000.00', '8 Hour', 'Male'),
(107, 'Partho Dev', 45, 'AGM_OM', '72000.00', '8 Hour', 'Male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agm_f`
--
ALTER TABLE `agm_f`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `agm_gs`
--
ALTER TABLE `agm_gs`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `agm_ms`
--
ALTER TABLE `agm_ms`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `agm_om`
--
ALTER TABLE `agm_om`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `staff_details`
--
ALTER TABLE `staff_details`
  ADD PRIMARY KEY (`Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
