package Staff_Information;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;
import net.proteanit.sql.DbUtils;

public class View_Page extends javax.swing.JFrame {
    
    public Connection con;
    public Statement st1, st2, st3, st4, st5, st6, st7;
    public ResultSet res, res1, res2, res3, res4;
    public String s1, s2, s3, s4, s5,s6, s7;
    
    public View_Page() {
        initComponents();
        Connection();
        
    }
    
    public void Connection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/staffinformation?zeroDateTimeBehavior=convertToNull", "root", "");
            st1 = con.createStatement();
            JOptionPane.showMessageDialog(null, "Connected");
        } catch (Exception ex) {
            System.out.println(ex);
            JOptionPane.showMessageDialog(null, "Not Connected");
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jRadioButtonMenuItem1 = new javax.swing.JRadioButtonMenuItem();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        Insert = new javax.swing.JPanel();
        InsertButton = new javax.swing.JButton();
        Exit = new javax.swing.JButton();
        Clear = new javax.swing.JButton();
        Name = new javax.swing.JLabel();
        Id = new javax.swing.JLabel();
        Age = new javax.swing.JLabel();
        Position = new javax.swing.JLabel();
        Salary = new javax.swing.JLabel();
        Time = new javax.swing.JLabel();
        Gender = new javax.swing.JLabel();
        jTextId = new javax.swing.JTextField();
        jTextName = new javax.swing.JTextField();
        jTextAge = new javax.swing.JTextField();
        jTextPosition = new javax.swing.JTextField();
        jTextSalary = new javax.swing.JTextField();
        jTextTime = new javax.swing.JTextField();
        jTextGender = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        sd = new javax.swing.JCheckBox();
        gs = new javax.swing.JCheckBox();
        ms = new javax.swing.JCheckBox();
        f = new javax.swing.JCheckBox();
        om = new javax.swing.JCheckBox();
        Show = new javax.swing.JButton();
        Update = new javax.swing.JPanel();
        Exit1 = new javax.swing.JButton();
        Done = new javax.swing.JButton();
        UpId = new javax.swing.JLabel();
        UpName = new javax.swing.JLabel();
        UpAge = new javax.swing.JLabel();
        UpPosition = new javax.swing.JLabel();
        UpSalary = new javax.swing.JLabel();
        UpTime = new javax.swing.JLabel();
        UpGender = new javax.swing.JLabel();
        TextTime = new javax.swing.JTextField();
        TextSalary = new javax.swing.JTextField();
        TextPosition = new javax.swing.JTextField();
        TextAge = new javax.swing.JTextField();
        TexName = new javax.swing.JTextField();
        TextId = new javax.swing.JTextField();
        TextGender = new javax.swing.JTextField();
        jLabelId = new javax.swing.JLabel();
        jTextFieldId = new javax.swing.JTextField();
        Search1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable6 = new javax.swing.JTable();
        sd1 = new javax.swing.JCheckBox();
        gs1 = new javax.swing.JCheckBox();
        ms1 = new javax.swing.JCheckBox();
        af = new javax.swing.JCheckBox();
        om1 = new javax.swing.JCheckBox();
        Show1 = new javax.swing.JButton();
        Clear1 = new javax.swing.JButton();
        PanelId = new javax.swing.JPanel();
        LabelId = new javax.swing.JLabel();
        TextFieldId = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        ButtonDelete = new javax.swing.JButton();
        Exit3 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        sd2 = new javax.swing.JCheckBox();
        gs2 = new javax.swing.JCheckBox();
        ms2 = new javax.swing.JCheckBox();
        af1 = new javax.swing.JCheckBox();
        om2 = new javax.swing.JCheckBox();
        Show2 = new javax.swing.JButton();
        Clear2 = new javax.swing.JButton();
        Search = new javax.swing.JPanel();
        Exit2 = new javax.swing.JButton();
        Show4 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        sdSearch = new javax.swing.JCheckBox();
        gsSearch = new javax.swing.JCheckBox();
        msSearch = new javax.swing.JCheckBox();
        fSearch = new javax.swing.JCheckBox();
        omSearch = new javax.swing.JCheckBox();
        jLabelId1 = new javax.swing.JLabel();
        jTextFieldId1 = new javax.swing.JTextField();
        Search3 = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable7 = new javax.swing.JTable();
        Name1 = new javax.swing.JLabel();
        jTextName1 = new javax.swing.JTextField();
        Clear3 = new javax.swing.JButton();

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 204));
        jLabel2.setText("Sylhet Palli Bidyut Samity-1");

        jRadioButtonMenuItem1.setSelected(true);
        jRadioButtonMenuItem1.setText("jRadioButtonMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("View_Page");
        setResizable(false);

        jTabbedPane1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        InsertButton.setText("Insert");
        InsertButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertButtonActionPerformed(evt);
            }
        });

        Exit.setText("Exit");
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });

        Clear.setText("Clear");
        Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearActionPerformed(evt);
            }
        });

        Name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Name.setText("Name");

        Id.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Id.setText("Id");

        Age.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Age.setText("Age");

        Position.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Position.setText("Position");

        Salary.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Salary.setText("Salary");

        Time.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Time.setText("WorkingTime");

        Gender.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Gender.setText("Gender");

        jTextId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextIdActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("Sylhet Palli Bidyut Samity-1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 525, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Name", "Age", "Position", "Salary", "WorkingTime", "Gender"
            }
        ));
        jScrollPane4.setViewportView(jTable4);

        sd.setText("Staff_details");
        sd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sdMouseClicked(evt);
            }
        });

        gs.setText("AGM_GS");
        gs.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                gsMouseClicked(evt);
            }
        });

        ms.setText("AGM_MS");
        ms.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                msMouseClicked(evt);
            }
        });

        f.setText("AGM_F");
        f.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                fMouseClicked(evt);
            }
        });

        om.setText("AMG_OM");
        om.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                omMouseClicked(evt);
            }
        });

        Show.setText("Show");
        Show.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ShowActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout InsertLayout = new javax.swing.GroupLayout(Insert);
        Insert.setLayout(InsertLayout);
        InsertLayout.setHorizontalGroup(
            InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(InsertLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(InsertLayout.createSequentialGroup()
                        .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(InsertLayout.createSequentialGroup()
                                .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(InsertLayout.createSequentialGroup()
                                        .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(Gender, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Time, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Salary, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Position, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Age, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Name, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(InsertLayout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jTextAge, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jTextPosition, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jTextSalary, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jTextTime, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jTextGender, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(InsertLayout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addComponent(jTextName, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(InsertLayout.createSequentialGroup()
                                        .addComponent(Id, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jTextId, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InsertLayout.createSequentialGroup()
                                .addComponent(InsertButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Clear)
                                .addGap(23, 23, 23)))
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 517, Short.MAX_VALUE))
                    .addGroup(InsertLayout.createSequentialGroup()
                        .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(om)
                            .addComponent(f)
                            .addGroup(InsertLayout.createSequentialGroup()
                                .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(sd)
                                    .addComponent(gs)
                                    .addComponent(ms))
                                .addGap(106, 106, 106)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(InsertLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(Show)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Exit)))
                .addContainerGap())
        );
        InsertLayout.setVerticalGroup(
            InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, InsertLayout.createSequentialGroup()
                .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(InsertLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(sd)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(gs)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ms)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(f)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(om)
                .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(InsertLayout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Id, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Name, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Age, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextAge, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Position, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextPosition, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Salary, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextSalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Time, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Gender, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextGender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)
                        .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(InsertButton)
                            .addComponent(Clear))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(InsertLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 355, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addGroup(InsertLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Exit)
                            .addComponent(Show))
                        .addContainerGap())))
        );

        jTabbedPane1.addTab("Insert", Insert);

        Exit1.setText("Exit");
        Exit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Exit1ActionPerformed(evt);
            }
        });

        Done.setText("Done");
        Done.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DoneActionPerformed(evt);
            }
        });

        UpId.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        UpId.setText("Id");

        UpName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        UpName.setText("Name");

        UpAge.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        UpAge.setText("Age");

        UpPosition.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        UpPosition.setText("Position");

        UpSalary.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        UpSalary.setText("Salary");

        UpTime.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        UpTime.setText("WorkingTime");

        UpGender.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        UpGender.setText("Gender");

        jLabelId.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabelId.setText("Id");

        jTextFieldId.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextFieldIdKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldIdKeyReleased(evt);
            }
        });

        Search1.setText("Search");
        Search1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Search1ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setText("Sylhet Palli Bidyut Samity-1");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 525, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 43, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTable6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Name", "Age", "Position", "Salary", "WorkingTime", "Gender"
            }
        ));
        jScrollPane6.setViewportView(jTable6);

        sd1.setText("Staff_details");
        sd1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sd1MouseClicked(evt);
            }
        });

        gs1.setText("AGM_GS");
        gs1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                gs1MouseClicked(evt);
            }
        });

        ms1.setText("AGM_MS");
        ms1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ms1MouseClicked(evt);
            }
        });

        af.setText("AGM_F");
        af.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                afMouseClicked(evt);
            }
        });

        om1.setText("AMG_OM");
        om1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                om1MouseClicked(evt);
            }
        });

        Show1.setText("Show");
        Show1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Show1ActionPerformed(evt);
            }
        });

        Clear1.setText("Clear");
        Clear1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Clear1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout UpdateLayout = new javax.swing.GroupLayout(Update);
        Update.setLayout(UpdateLayout);
        UpdateLayout.setHorizontalGroup(
            UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UpdateLayout.createSequentialGroup()
                .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UpdateLayout.createSequentialGroup()
                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(UpdateLayout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(UpdateLayout.createSequentialGroup()
                                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(UpName, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(UpAge, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(UpPosition, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(UpId, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(24, 24, 24)
                                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(TextId, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(TexName, javax.swing.GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
                                                .addComponent(TextPosition, javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(TextAge, javax.swing.GroupLayout.Alignment.TRAILING))))
                                    .addGroup(UpdateLayout.createSequentialGroup()
                                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(UpTime, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(UpSalary, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(UpdateLayout.createSequentialGroup()
                                                .addGap(5, 5, 5)
                                                .addComponent(TextSalary, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(UpdateLayout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(TextGender, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(TextTime, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                    .addComponent(UpGender, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UpdateLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(Clear1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Done)
                                .addGap(15, 15, 15)))
                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(UpdateLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(Show1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Exit1))
                            .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 517, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UpdateLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(UpdateLayout.createSequentialGroup()
                                .addComponent(om1)
                                .addGap(170, 170, 170)
                                .addComponent(jLabelId, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jTextFieldId, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(Search1))
                            .addGroup(UpdateLayout.createSequentialGroup()
                                .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(sd1)
                                    .addComponent(gs1)
                                    .addComponent(af)
                                    .addComponent(ms1))
                                .addGap(139, 139, 139)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 523, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        UpdateLayout.setVerticalGroup(
            UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UpdateLayout.createSequentialGroup()
                .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(UpdateLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(sd1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(gs1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ms1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(af)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(om1)
                    .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabelId)
                        .addComponent(jTextFieldId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Search1)))
                .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(UpdateLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Exit1)
                            .addComponent(Show1))
                        .addContainerGap())
                    .addGroup(UpdateLayout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(UpId, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TexName, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(UpName, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(UpAge, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextAge, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(UpPosition, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextPosition, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(UpSalary, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextSalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(UpTime, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(UpGender, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextGender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(UpdateLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Done)
                            .addComponent(Clear1))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jTabbedPane1.addTab("Update", Update);

        LabelId.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        LabelId.setText("Id");

        TextFieldId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextFieldIdActionPerformed(evt);
            }
        });

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Name", "Age", "Position", "Salary", "WorkingTime", "Gender"
            }
        ));
        jScrollPane3.setViewportView(jTable3);

        ButtonDelete.setText("Delete");
        ButtonDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonDeleteActionPerformed(evt);
            }
        });

        Exit3.setText("Exit");
        Exit3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Exit3ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setText("Sylhet Palli Bidyut Samity-1");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        sd2.setText("Staff_details");
        sd2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sd2MouseClicked(evt);
            }
        });

        gs2.setText("AGM_GS");
        gs2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                gs2MouseClicked(evt);
            }
        });

        ms2.setText("AGM_MS");
        ms2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ms2MouseClicked(evt);
            }
        });

        af1.setText("AGM_F");
        af1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                af1MouseClicked(evt);
            }
        });

        om2.setText("AMG_OM");
        om2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                om2MouseClicked(evt);
            }
        });

        Show2.setText("Show");
        Show2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Show2ActionPerformed(evt);
            }
        });

        Clear2.setText("Clear");
        Clear2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Clear2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelIdLayout = new javax.swing.GroupLayout(PanelId);
        PanelId.setLayout(PanelIdLayout);
        PanelIdLayout.setHorizontalGroup(
            PanelIdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelIdLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelIdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelIdLayout.createSequentialGroup()
                        .addGroup(PanelIdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(af1)
                            .addGroup(PanelIdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, PanelIdLayout.createSequentialGroup()
                                    .addComponent(om2)
                                    .addGap(42, 42, 42)
                                    .addComponent(LabelId, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(TextFieldId, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(ButtonDelete)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(Clear2))
                                .addGroup(PanelIdLayout.createSequentialGroup()
                                    .addGroup(PanelIdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(sd2)
                                        .addComponent(gs2)
                                        .addComponent(ms2))
                                    .addGap(101, 101, 101)
                                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 131, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelIdLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 694, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Show2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Exit3)))
                .addContainerGap())
        );
        PanelIdLayout.setVerticalGroup(
            PanelIdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelIdLayout.createSequentialGroup()
                .addGroup(PanelIdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelIdLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(sd2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(gs2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ms2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(af1))
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(PanelIdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelIdLayout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(om2))
                    .addGroup(PanelIdLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PanelIdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(LabelId, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextFieldId, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ButtonDelete)
                            .addComponent(Clear2))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addGroup(PanelIdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Exit3)
                    .addComponent(Show2))
                .addGap(12, 12, 12))
        );

        jTabbedPane1.addTab("Delete", PanelId);

        Exit2.setText("Exit");
        Exit2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Exit2ActionPerformed(evt);
            }
        });

        Show4.setText("Show");
        Show4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Show4ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setText("Sylhet Palli Bidyut Samity-1");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 525, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        sdSearch.setText("Staff_details");
        sdSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sdSearchMouseClicked(evt);
            }
        });

        gsSearch.setText("AGM_GS");
        gsSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                gsSearchMouseClicked(evt);
            }
        });

        msSearch.setText("AGM_MS");
        msSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                msSearchMouseClicked(evt);
            }
        });

        fSearch.setText("AGM_F");
        fSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                fSearchMouseClicked(evt);
            }
        });

        omSearch.setText("AMG_OM");
        omSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                omSearchMouseClicked(evt);
            }
        });

        jLabelId1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabelId1.setText("Id");

        jTextFieldId1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextFieldId1KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldId1KeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldId1KeyTyped(evt);
            }
        });

        Search3.setText("Search");
        Search3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Search3ActionPerformed(evt);
            }
        });

        jTable7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Name", "Age", "Position", "Salary", "WorkingTime", "Gender"
            }
        ));
        jScrollPane7.setViewportView(jTable7);

        Name1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Name1.setText("Name");

        jTextName1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextName1KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextName1KeyReleased(evt);
            }
        });

        Clear3.setText("Clear");
        Clear3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Clear3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout SearchLayout = new javax.swing.GroupLayout(Search);
        Search.setLayout(SearchLayout);
        SearchLayout.setHorizontalGroup(
            SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SearchLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SearchLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(Show4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Exit2)
                        .addGap(22, 22, 22))
                    .addGroup(SearchLayout.createSequentialGroup()
                        .addComponent(sdSearch)
                        .addGap(104, 104, 104)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(SearchLayout.createSequentialGroup()
                        .addGroup(SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(msSearch)
                            .addComponent(omSearch)
                            .addComponent(gsSearch)
                            .addComponent(fSearch)
                            .addGroup(SearchLayout.createSequentialGroup()
                                .addGroup(SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Name1, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabelId1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextFieldId1, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(SearchLayout.createSequentialGroup()
                                            .addComponent(Search3)
                                            .addGap(18, 18, 18)
                                            .addComponent(Clear3))
                                        .addComponent(jTextName1, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 545, Short.MAX_VALUE)
                        .addGap(21, 21, 21))))
        );
        SearchLayout.setVerticalGroup(
            SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SearchLayout.createSequentialGroup()
                .addGroup(SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sdSearch))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SearchLayout.createSequentialGroup()
                        .addComponent(gsSearch)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(msSearch)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(fSearch)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(omSearch)
                        .addGap(28, 28, 28)
                        .addGroup(SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldId1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelId1))
                        .addGap(18, 18, 18)
                        .addGroup(SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Name1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Search3)
                            .addComponent(Clear3)))
                    .addGroup(SearchLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addGroup(SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Exit2)
                    .addComponent(Show4))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Search", Search);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 607, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearActionPerformed
        jTextId.setText("");
        jTextName.setText("");
        jTextAge.setText("");
        jTextPosition.setText("");
        jTextSalary.setText("");
        jTextTime.setText("");
        jTextGender.setText("");
        

    }//GEN-LAST:event_ClearActionPerformed

    private void ExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_ExitActionPerformed

    private void Exit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Exit1ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_Exit1ActionPerformed

    private void Exit2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Exit2ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_Exit2ActionPerformed

    private void jTextIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextIdActionPerformed

    private void InsertButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertButtonActionPerformed
        try {
            if (sd.isSelected()) {
                
                String id = "", name = "", age = "", position = "", salary = "", time = "", gender = "";
                id = jTextId.getText();
                name = jTextName.getText();
                age = jTextAge.getText();
                position = jTextPosition.getText();
                salary = jTextSalary.getText();
                time = jTextTime.getText();
                gender = jTextGender.getText();
                
                s1 = "insert into staff_details(Id,Name,Age,Position,Salary,Workingtime,Gender)"
                        + "values('" + id + "','" + name + "','" + age + "','" + position + "','" + salary + "','" + time + "','" + gender + "')";
                st1.executeUpdate(s1);
                JOptionPane.showMessageDialog(null, "New Staff Add In Staff_details Table");
                
            } else if (gs.isSelected()) {
                String id = "", name = "", age = "", position = "", salary = "", time = "", gender = "";
                id = jTextId.getText();
                name = jTextName.getText();
                age = jTextAge.getText();
                position = jTextPosition.getText();
                salary = jTextSalary.getText();
                time = jTextTime.getText();
                gender = jTextGender.getText();
                
                s1 = "insert into agm_gs(Id,Name,Age,Position,Salary,Workingtime,Gender)"
                        + "values('" + id + "','" + name + "','" + age + "','" + position + "','" + salary + "','" + time + "','" + gender + "')";
                st1.executeUpdate(s1);
                JOptionPane.showMessageDialog(null, "New Staff Add In AGM_GS Table");
            } else if (ms.isSelected()) {
                String id = "", name = "", age = "", position = "", salary = "", time = "", gender = "";
                id = jTextId.getText();
                name = jTextName.getText();
                age = jTextAge.getText();
                position = jTextPosition.getText();
                salary = jTextSalary.getText();
                time = jTextTime.getText();
                gender = jTextGender.getText();
                
                s1 = "insert into agm_ms(Id,Name,Age,Position,Salary,Workingtime,Gender)"
                        + "values('" + id + "','" + name + "','" + age + "','" + position + "','" + salary + "','" + time + "','" + gender + "')";
                st1.executeUpdate(s1);
                JOptionPane.showMessageDialog(null, "New Staff Add In AGM_MS Table");
            } else if (f.isSelected()) {
                String id = "", name = "", age = "", position = "", salary = "", time = "", gender = "";
                id = jTextId.getText();
                name = jTextName.getText();
                age = jTextAge.getText();
                position = jTextPosition.getText();
                salary = jTextSalary.getText();
                time = jTextTime.getText();
                gender = jTextGender.getText();
                
                s1 = "insert into agm_f(Id,Name,Age,Position,Salary,Workingtime,Gender)"
                        + "values('" + id + "','" + name + "','" + age + "','" + position + "','" + salary + "','" + time + "','" + gender + "')";
                st1.executeUpdate(s1);
                JOptionPane.showMessageDialog(null, "New Staff Add In AGM_F Table");
            } else if (om.isSelected()) {
                String id = "", name = "", age = "", position = "", salary = "", time = "", gender = "";
                id = jTextId.getText();
                name = jTextName.getText();
                age = jTextAge.getText();
                position = jTextPosition.getText();
                salary = jTextSalary.getText();
                time = jTextTime.getText();
                gender = jTextGender.getText();
                
                s1 = "insert into agm_om(Id,Name,Age,Position,Salary,Workingtime,Gender)"
                        + "values('" + id + "','" + name + "','" + age + "','" + position + "','" + salary + "','" + time + "','" + gender + "')";
                st1.executeUpdate(s1);
                JOptionPane.showMessageDialog(null, "New Staff Add In AGM_OM Table");
            } else {
                JOptionPane.showMessageDialog(null, "Please select any checkbox!!! ");
            }
        } catch (Exception ex) {
            System.out.println(ex);
            JOptionPane.showMessageDialog(null, "Exception :" + ex);
        }
    }//GEN-LAST:event_InsertButtonActionPerformed

    private void TextFieldIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextFieldIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextFieldIdActionPerformed

    private void Exit3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Exit3ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_Exit3ActionPerformed

    private void Search1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Search1ActionPerformed
        try {
            if (sd1.isSelected()) {
                String sql = "select * from staff_details where Id=?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, jTextFieldId.getText());
                res = pst.executeQuery();
                if (res.next()) {
                    String a1 = res.getString("Id");
                    TextId.setText(a1);
                    String a2 = res.getString("Name");
                    TexName.setText(a2);
                    String a3 = res.getString("Age");
                    TextAge.setText(a3);
                    String a4 = res.getString("Position");
                    TextPosition.setText(a4);
                    String a5 = res.getString("Salary");
                    TextSalary.setText(a5);
                    String a6 = res.getString("Workingtime");
                    TextTime.setText(a6);
                    String a7 = res.getString("Gender");
                    TextGender.setText(a7);
                    //JOptionPane.showMessageDialog(null, "Done");
                }
            } else if (gs1.isSelected()) {
                String sql = "select * from agm_gs where Id=?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, jTextFieldId.getText());
                res = pst.executeQuery();
                if (res.next()) {
                    String a1 = res.getString("Id");
                    TextId.setText(a1);
                    String a2 = res.getString("Name");
                    TexName.setText(a2);
                    String a3 = res.getString("Age");
                    TextAge.setText(a3);
                    String a4 = res.getString("Position");
                    TextPosition.setText(a4);
                    String a5 = res.getString("Salary");
                    TextSalary.setText(a5);
                    String a6 = res.getString("Workingtime");
                    TextTime.setText(a6);
                    String a7 = res.getString("Gender");
                    TextGender.setText(a7);
                    
                }
            } else if (ms1.isSelected()) {
                String sql = "select * from agm_ms where Id=?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, jTextFieldId.getText());
                res = pst.executeQuery();
                if (res.next()) {
                    String a1 = res.getString("Id");
                    TextId.setText(a1);
                    String a2 = res.getString("Name");
                    TexName.setText(a2);
                    String a3 = res.getString("Age");
                    TextAge.setText(a3);
                    String a4 = res.getString("Position");
                    TextPosition.setText(a4);
                    String a5 = res.getString("Salary");
                    TextSalary.setText(a5);
                    String a6 = res.getString("Workingtime");
                    TextTime.setText(a6);
                    String a7 = res.getString("Gender");
                    TextGender.setText(a7);
                    
                }
            } else if (af.isSelected()) {
                String sql = "select * from agm_f where Id=?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, jTextFieldId.getText());
                res = pst.executeQuery();
                if (res.next()) {
                    String a1 = res.getString("Id");
                    TextId.setText(a1);
                    String a2 = res.getString("Name");
                    TexName.setText(a2);
                    String a3 = res.getString("Age");
                    TextAge.setText(a3);
                    String a4 = res.getString("Position");
                    TextPosition.setText(a4);
                    String a5 = res.getString("Salary");
                    TextSalary.setText(a5);
                    String a6 = res.getString("Workingtime");
                    TextTime.setText(a6);
                    String a7 = res.getString("Gender");
                    TextGender.setText(a7);
                    
                }
            } else if (om1.isSelected()) {
                String sql = "select * from agm_om where Id=?";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, jTextFieldId.getText());
                res = pst.executeQuery();
                if (res.next()) {
                    String a1 = res.getString("Id");
                    TextId.setText(a1);
                    String a2 = res.getString("Name");
                    TexName.setText(a2);
                    String a3 = res.getString("Age");
                    TextAge.setText(a3);
                    String a4 = res.getString("Position");
                    TextPosition.setText(a4);
                    String a5 = res.getString("Salary");
                    TextSalary.setText(a5);
                    String a6 = res.getString("Workingtime");
                    TextTime.setText(a6);
                    String a7 = res.getString("Gender");
                    TextGender.setText(a7);
                    
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please select any checkbox!!! ");
            }
            
        } catch (Exception ex1) {
            JOptionPane.showMessageDialog(null, "Exception :" + ex1);
        }
    }//GEN-LAST:event_Search1ActionPerformed

    private void DoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DoneActionPerformed
        
        try {
            if (sd1.isSelected()) {
                st2 = con.createStatement();
                String Id = "", Name = "", Age = "", Position = "", Salary = "", WorkingTime = "", Gender = "";
                Id = TextId.getText();
                Name = TexName.getText();
                Age = TextAge.getText();
                Position = TextPosition.getText();
                Salary = TextSalary.getText();
                WorkingTime = TextTime.getText();
                Gender = TextGender.getText();
                
                s2 = "Update staff_details Set Id='" + Id + "',Name='" + Name + "',Age='" + Age + "',Position='" + Position + "',Salary='" + Salary + "',Workingtime='" + WorkingTime + "',Gender='" + Gender + "' where Id='" + Id + "'";
                
                st2.executeUpdate(s2);
                JOptionPane.showMessageDialog(null, "Staff_details is now update");
            } else if (gs1.isSelected()) {
                st2 = con.createStatement();
                String Id = "", Name = "", Age = "", Position = "", Salary = "", WorkingTime = "", Gender = "";
                Id = TextId.getText();
                Name = TexName.getText();
                Age = TextAge.getText();
                Position = TextPosition.getText();
                Salary = TextSalary.getText();
                WorkingTime = TextTime.getText();
                Gender = TextGender.getText();
                
                s2 = "Update agm_gs Set Id='" + Id + "',Name='" + Name + "',Age='" + Age + "',Position='" + Position + "',Salary='" + Salary + "',Workingtime='" + WorkingTime + "',Gender='" + Gender + "' where Id='" + Id + "'";
                
                st2.executeUpdate(s2);
                JOptionPane.showMessageDialog(null, "AGM_GS is now update");
            } else if (ms1.isSelected()) {
                st2 = con.createStatement();
                String Id = "", Name = "", Age = "", Position = "", Salary = "", WorkingTime = "", Gender = "";
                Id = TextId.getText();
                Name = TexName.getText();
                Age = TextAge.getText();
                Position = TextPosition.getText();
                Salary = TextSalary.getText();
                WorkingTime = TextTime.getText();
                Gender = TextGender.getText();
                
                s2 = "Update agm_ms Set Id='" + Id + "',Name='" + Name + "',Age='" + Age + "',Position='" + Position + "',Salary='" + Salary + "',Workingtime='" + WorkingTime + "',Gender='" + Gender + "' where Id='" + Id + "'";
                
                st2.executeUpdate(s2);
                JOptionPane.showMessageDialog(null, "AGM_MS is now update");
            } else if (af.isSelected()) {
                st2 = con.createStatement();
                String Id = "", Name = "", Age = "", Position = "", Salary = "", WorkingTime = "", Gender = "";
                Id = TextId.getText();
                Name = TexName.getText();
                Age = TextAge.getText();
                Position = TextPosition.getText();
                Salary = TextSalary.getText();
                WorkingTime = TextTime.getText();
                Gender = TextGender.getText();
                
                s2 = "Update agm_f Set Id='" + Id + "',Name='" + Name + "',Age='" + Age + "',Position='" + Position + "',Salary='" + Salary + "',Workingtime='" + WorkingTime + "',Gender='" + Gender + "' where Id='" + Id + "'";
                
                st2.executeUpdate(s2);
                JOptionPane.showMessageDialog(null, "AGM_F is now update");
            } else if (om1.isSelected()) {
                st2 = con.createStatement();
                String Id = "", Name = "", Age = "", Position = "", Salary = "", WorkingTime = "", Gender = "";
                Id = TextId.getText();
                Name = TexName.getText();
                Age = TextAge.getText();
                Position = TextPosition.getText();
                Salary = TextSalary.getText();
                WorkingTime = TextTime.getText();
                Gender = TextGender.getText();
                
                s2 = "Update agm_om Set Id='" + Id + "',Name='" + Name + "',Age='" + Age + "',Position='" + Position + "',Salary='" + Salary + "',Workingtime='" + WorkingTime + "',Gender='" + Gender + "' where Id='" + Id + "'";
                
                st2.executeUpdate(s2);
                JOptionPane.showMessageDialog(null, "AGM_OM is now update");
            } else {
                JOptionPane.showMessageDialog(null, "Data Not Found!!");
            }
        } catch (Exception ex2) {
            JOptionPane.showMessageDialog(null, "Exception in table:" + ex2);
        }
        

    }//GEN-LAST:event_DoneActionPerformed

    private void ButtonDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonDeleteActionPerformed
        
        try {
            if (sd2.isSelected()) {
                st3 = con.createStatement();
                String DeleteId = TextFieldId.getText();
                
                s3 = "Delete from Staff_details where ID='" + DeleteId + "'";
                System.out.println(s3);
                st3.executeUpdate(s3);
                JOptionPane.showMessageDialog(null, "Selected staff info is now deleted!");
            } else if (gs2.isSelected()) {
                st3 = con.createStatement();
                String DeleteId = TextFieldId.getText();
                
                s3 = "Delete from agm_gs where ID='" + DeleteId + "'";
                System.out.println(s3);
                st3.executeUpdate(s3);
                JOptionPane.showMessageDialog(null, "Selected staff info is now deleted!");
            } else if (ms2.isSelected()) {
                st3 = con.createStatement();
                String DeleteId = TextFieldId.getText();
                
                s3 = "Delete from agm_ms where ID='" + DeleteId + "'";
                System.out.println(s3);
                st3.executeUpdate(s3);
                JOptionPane.showMessageDialog(null, "Selected staff info is now deleted!");
            } else if (af1.isSelected()) {
                st3 = con.createStatement();
                String DeleteId = TextFieldId.getText();
                
                s3 = "Delete from agm_f where ID='" + DeleteId + "'";
                System.out.println(s3);
                st3.executeUpdate(s3);
                JOptionPane.showMessageDialog(null, "Selected staff info is now deleted!");
            } else if (om2.isSelected()) {
                st3 = con.createStatement();
                String DeleteId = TextFieldId.getText();
                
                s3 = "Delete from agm_om where ID='" + DeleteId + "'";
                System.out.println(s3);
                st3.executeUpdate(s3);
                JOptionPane.showMessageDialog(null, "Selected staff info is now deleted!");
            } else {
                JOptionPane.showMessageDialog(null, "Data Not Found!Please select any checkbox!!");
            }
        } catch (Exception e3) {
            JOptionPane.showMessageDialog(null, "Exception::: " + e3);
        }

    }//GEN-LAST:event_ButtonDeleteActionPerformed

    private void Show4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Show4ActionPerformed

        
        //int ok = 0;
        //if (sdSearch.isSelected()) {
          //  s4 = "select * from staff_details";
        //} else if (gsSearch.isSelected()) {
          //  s4 = "select * from agm_gs";
        //} else if (msSearch.isSelected()) {
          //  s4 = "select * from agm_ms";
        //} else if (fSearch.isSelected()) {
          //  s4 = "select * from agm_f";
        //} else if (omSearch.isSelected()) {
          //  s4 = "select * from agm_om";
        //}else {
          //      JOptionPane.showMessageDialog(null, "Data Not Found!Please select any checkbox!!");
            //}

      //  try {
        //    st4 = con.createStatement();
          //  System.out.println(s4);
            //res1 = st4.executeQuery(s4);
            
            //String ans = "";
            
          //  while (res1.next()) {
            //    String id = res1.getString("Id");
              //  String name = res1.getString("Name");
                //String age = res1.getString("Age");
               // String position = res1.getString("Position");
               // String salary = res1.getString("Salary");
                //String time = res1.getString("Workingtime");
                //String gender = res1.getString("Gender");
                
                //ans += "Id: " + id + "\n" + "Name: " + name + "\n" + "Age: " + age + "\n" + "Position: " + position + "\n" + "Salary: " + salary + "\n" + "Workingtime: " + time + "\n" + "Gender: " + gender + "\n\n\n";
                //System.out.println(ans);
                
           // }
           // resArea.setText(ans);
          //  ok = 0;
        //} catch (Exception e4) {
          //  JOptionPane.showMessageDialog(null, "Exception::: " + e4);
      //  }
      
      try {
            st5 = con.createStatement();
            if (sdSearch.isSelected()) {
                s5 = "select * from staff_details";
            } else if (gsSearch.isSelected()) {
                s5 = "select * from agm_gs";
            } else if (msSearch.isSelected()) {
                s5 = "select * from agm_ms";
            } else if (fSearch.isSelected()) {
                s5 = "select * from agm_f";
            } else if (omSearch.isSelected()) {
                s5 = "select * from agm_om";
            }else {
                JOptionPane.showMessageDialog(null, "Data Not Found!Please select any checkbox!!");
            }
            res2 = st5.executeQuery(s5);
            jTable7.setModel(DbUtils.resultSetToTableModel(res2));
        } catch (Exception e5) {
            e5.printStackTrace();
            
        }
        

    }//GEN-LAST:event_Show4ActionPerformed

    private void sdMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sdMouseClicked
        // TODO add your handling code here:
        gs.setSelected(false);
        ms.setSelected(false);
        f.setSelected(false);
        om.setSelected(false);
    }//GEN-LAST:event_sdMouseClicked

    private void gsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_gsMouseClicked
        // TODO add your handling code here:\
        sd.setSelected(false);
        ms.setSelected(false);
        f.setSelected(false);
        om.setSelected(false);

    }//GEN-LAST:event_gsMouseClicked

    private void msMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_msMouseClicked
        // TODO add your handling code here:
        gs.setSelected(false);
        sd.setSelected(false);
        f.setSelected(false);
        om.setSelected(false);
    }//GEN-LAST:event_msMouseClicked

    private void fMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fMouseClicked
        // TODO add your handling code here:
        gs.setSelected(false);
        ms.setSelected(false);
        sd.setSelected(false);
        om.setSelected(false);
    }//GEN-LAST:event_fMouseClicked

    private void omMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_omMouseClicked
        // TODO add your handling code here:
        gs.setSelected(false);
        ms.setSelected(false);
        f.setSelected(false);
        sd.setSelected(false);
    }//GEN-LAST:event_omMouseClicked

    private void sd1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sd1MouseClicked
        gs1.setSelected(false);
        ms1.setSelected(false);
        af.setSelected(false);
        om1.setSelected(false);
    }//GEN-LAST:event_sd1MouseClicked

    private void gs1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_gs1MouseClicked
        sd1.setSelected(false);
        ms1.setSelected(false);
        af.setSelected(false);
        om1.setSelected(false);
    }//GEN-LAST:event_gs1MouseClicked

    private void ms1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ms1MouseClicked
        gs1.setSelected(false);
        sd1.setSelected(false);
        af.setSelected(false);
        om1.setSelected(false);
    }//GEN-LAST:event_ms1MouseClicked

    private void afMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_afMouseClicked
        gs1.setSelected(false);
        ms1.setSelected(false);
        sd1.setSelected(false);
        om1.setSelected(false);
    }//GEN-LAST:event_afMouseClicked

    private void om1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_om1MouseClicked
        gs1.setSelected(false);
        ms1.setSelected(false);
        af.setSelected(false);
        sd1.setSelected(false);
    }//GEN-LAST:event_om1MouseClicked

    private void sd2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sd2MouseClicked
        gs2.setSelected(false);
        ms2.setSelected(false);
        af1.setSelected(false);
        om2.setSelected(false);
    }//GEN-LAST:event_sd2MouseClicked

    private void gs2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_gs2MouseClicked
        sd2.setSelected(false);
        ms2.setSelected(false);
        af1.setSelected(false);
        om2.setSelected(false);
    }//GEN-LAST:event_gs2MouseClicked

    private void ms2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ms2MouseClicked
        gs2.setSelected(false);
        sd2.setSelected(false);
        af1.setSelected(false);
        om2.setSelected(false);
    }//GEN-LAST:event_ms2MouseClicked

    private void af1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_af1MouseClicked
        gs2.setSelected(false);
        ms2.setSelected(false);
        sd2.setSelected(false);
        om2.setSelected(false);
    }//GEN-LAST:event_af1MouseClicked

    private void om2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_om2MouseClicked
        gs2.setSelected(false);
        ms2.setSelected(false);
        af1.setSelected(false);
        sd2.setSelected(false);
    }//GEN-LAST:event_om2MouseClicked

    private void sdSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sdSearchMouseClicked
        gsSearch.setSelected(false);
        msSearch.setSelected(false);
        fSearch.setSelected(false);
        omSearch.setSelected(false);
    }//GEN-LAST:event_sdSearchMouseClicked

    private void gsSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_gsSearchMouseClicked
        sdSearch.setSelected(false);
        msSearch.setSelected(false);
        fSearch.setSelected(false);
        omSearch.setSelected(false);
    }//GEN-LAST:event_gsSearchMouseClicked

    private void msSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_msSearchMouseClicked
        gsSearch.setSelected(false);
        sdSearch.setSelected(false);
        fSearch.setSelected(false);
        omSearch.setSelected(false);
    }//GEN-LAST:event_msSearchMouseClicked

    private void fSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fSearchMouseClicked
        gsSearch.setSelected(false);
        msSearch.setSelected(false);
        sdSearch.setSelected(false);
        omSearch.setSelected(false);
    }//GEN-LAST:event_fSearchMouseClicked

    private void omSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_omSearchMouseClicked
        gsSearch.setSelected(false);
        msSearch.setSelected(false);
        fSearch.setSelected(false);
        sdSearch.setSelected(false);
    }//GEN-LAST:event_omSearchMouseClicked

    private void ShowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ShowActionPerformed
        try {
            st5 = con.createStatement();
            if (sd.isSelected()) {
                s5 = "select * from staff_details";
            } else if (gs.isSelected()) {
                s5 = "select * from agm_gs";
            } else if (ms.isSelected()) {
                s5 = "select * from agm_ms";
            } else if (f.isSelected()) {
                s5 = "select * from agm_f";
            } else if (om.isSelected()) {
                s5 = "select * from agm_om";
            }else {
                JOptionPane.showMessageDialog(null, "Data Not Found!Please select any checkbox!!");
            }
            res2 = st5.executeQuery(s5);
            jTable4.setModel(DbUtils.resultSetToTableModel(res2));
        } catch (Exception e5) {
            e5.printStackTrace();
            
        }
    }//GEN-LAST:event_ShowActionPerformed

    private void Show1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Show1ActionPerformed
        try {
            st6 = con.createStatement();
            if (sd1.isSelected()) {
                s6 = "select * from staff_details";
            } else if (gs1.isSelected()) {
                s6 = "select * from agm_gs";
            } else if (ms1.isSelected()) {
                s6 = "select * from agm_ms";
            } else if (af.isSelected()) {
                s6 = "select * from agm_f";
            } else if (om1.isSelected()) {
                s6 = "select * from agm_om";
            }else {
                JOptionPane.showMessageDialog(null, "Data Not Found!Please select any checkbox!!");
            }
            res3 = st6.executeQuery(s6);
            jTable6.setModel(DbUtils.resultSetToTableModel(res3));
        } catch (Exception e5) {
            e5.printStackTrace();
            
        }
    }//GEN-LAST:event_Show1ActionPerformed

    private void Show2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Show2ActionPerformed
        try {
            st7 = con.createStatement();
            if (sd2.isSelected()) {
                s7 = "select * from staff_details";
            } else if (gs2.isSelected()) {
                s7 = "select * from agm_gs";
            } else if (ms2.isSelected()) {
                s7 = "select * from agm_ms";
            } else if (af1.isSelected()) {
                s7 = "select * from agm_f";
            } else if (om2.isSelected()) {
                s7 = "select * from agm_om";
            }else {
                JOptionPane.showMessageDialog(null, "Data Not Found!Please select any checkbox!!");
            }
            res4 = st7.executeQuery(s7);
            jTable3.setModel(DbUtils.resultSetToTableModel(res4));
        } catch (Exception e5) {
            e5.printStackTrace();
            
        }
    }//GEN-LAST:event_Show2ActionPerformed

    private void Clear1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Clear1ActionPerformed
        jTextFieldId.setText("");
        TextId.setText("");
        TexName.setText("");
        TextAge.setText("");
        TextPosition.setText("");
        TextSalary.setText("");
        TextTime.setText("");
        TextGender.setText("");
    }//GEN-LAST:event_Clear1ActionPerformed

    private void Clear2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Clear2ActionPerformed
        TextFieldId.setText("");
    }//GEN-LAST:event_Clear2ActionPerformed

    private void Search3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Search3ActionPerformed
         try {
            st5 = con.createStatement();
            if (sdSearch.isSelected()) {
                s5 = "select * from staff_details";
            } else if (gsSearch.isSelected()) {
                s5 = "select * from agm_gs";
            } else if (msSearch.isSelected()) {
                s5 = "select * from agm_ms";
            } else if (fSearch.isSelected()) {
                s5 = "select * from agm_f";
            } else if (omSearch.isSelected()) {
                s5 = "select * from agm_om";
            }else {
                JOptionPane.showMessageDialog(null, "Data Not Found!Please select any checkbox!!");
            }
            res2 = st5.executeQuery(s5);
            jTable7.setModel(DbUtils.resultSetToTableModel(res2));
        } catch (Exception e5) {
            e5.printStackTrace();
            
        }
    }//GEN-LAST:event_Search3ActionPerformed

    private void jTextFieldId1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldId1KeyPressed
         try {
            st5 = con.createStatement();
            if (sdSearch.isSelected()) {
                s5 = "select * from staff_details";
            } else if (gsSearch.isSelected()) {
                s5 = "select * from agm_gs";
            } else if (msSearch.isSelected()) {
                s5 = "select * from agm_ms";
            } else if (fSearch.isSelected()) {
                s5 = "select * from agm_f";
            } else if (omSearch.isSelected()) {
                s5 = "select * from agm_om";
            }else {
                JOptionPane.showMessageDialog(null, "Data Not Found!Please select any checkbox!!");
            }
            res2 = st5.executeQuery(s5);
            jTable7.setModel(DbUtils.resultSetToTableModel(res2));
        } catch (Exception e5) {
            e5.printStackTrace();
            
        }
    }//GEN-LAST:event_jTextFieldId1KeyPressed

    private void jTextName1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextName1KeyPressed
        try {
            st5 = con.createStatement();
            if (sdSearch.isSelected()) {
                s5 = "select * from staff_details";
            } else if (gsSearch.isSelected()) {
                s5 = "select * from agm_gs";
            } else if (msSearch.isSelected()) {
                s5 = "select * from agm_ms";
            } else if (fSearch.isSelected()) {
                s5 = "select * from agm_f";
            } else if (omSearch.isSelected()) {
                s5 = "select * from agm_om";
            }else {
                JOptionPane.showMessageDialog(null, "Data Not Found!Please select any checkbox!!");
            }
            res2 = st5.executeQuery(s5);
            jTable7.setModel(DbUtils.resultSetToTableModel(res2));
        } catch (Exception e5) {
            e5.printStackTrace();
            
        }
    }//GEN-LAST:event_jTextName1KeyPressed

    private void Clear3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Clear3ActionPerformed
        jTextFieldId1.setText("");
                jTextName1.setText("");
    }//GEN-LAST:event_Clear3ActionPerformed

    private void jTextFieldId1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldId1KeyReleased
         try {
            st5 = con.createStatement();
            if (sdSearch.isSelected()) {
                s5 = "select * from staff_details";
            } else if (gsSearch.isSelected()) {
                s5 = "select * from agm_gs";
            } else if (msSearch.isSelected()) {
                s5 = "select * from agm_ms";
            } else if (fSearch.isSelected()) {
                s5 = "select * from agm_f";
            } else if (omSearch.isSelected()) {
                s5 = "select * from agm_om";
            }else {
                JOptionPane.showMessageDialog(null, "Data Not Found!Please select any checkbox!!");
            }
            res2 = st5.executeQuery(s5);
            jTable7.setModel(DbUtils.resultSetToTableModel(res2));
        } catch (Exception e5) {
            e5.printStackTrace();
            
        }
                                           
    }//GEN-LAST:event_jTextFieldId1KeyReleased

    private void jTextName1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextName1KeyReleased
        try {
            st5 = con.createStatement();
            if (sdSearch.isSelected()) {
                s5 = "select * from staff_details";
            } else if (gsSearch.isSelected()) {
                s5 = "select * from agm_gs";
            } else if (msSearch.isSelected()) {
                s5 = "select * from agm_ms";
            } else if (fSearch.isSelected()) {
                s5 = "select * from agm_f";
            } else if (omSearch.isSelected()) {
                s5 = "select * from agm_om";
            }else {
                JOptionPane.showMessageDialog(null, "Data Not Found!Please select any checkbox!!");
            }
            res2 = st5.executeQuery(s5);
            jTable7.setModel(DbUtils.resultSetToTableModel(res2));
        } catch (Exception e5) {
            e5.printStackTrace();
            
        }
                                            
    }//GEN-LAST:event_jTextName1KeyReleased

    private void jTextFieldId1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldId1KeyTyped
         
    }//GEN-LAST:event_jTextFieldId1KeyTyped

    private void jTextFieldIdKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldIdKeyPressed
         try {
            st5 = con.createStatement();
            if (sd1.isSelected()) {
                s5 = "select * from staff_details";
            } else if (gs1.isSelected()) {
                s5 = "select * from agm_gs";
            } else if (ms1.isSelected()) {
                s5 = "select * from agm_ms";
            } else if (af.isSelected()) {
                s5 = "select * from agm_f";
            } else if (om1.isSelected()) {
                s5 = "select * from agm_om";
            }else {
                JOptionPane.showMessageDialog(null, "Data Not Found!Please select any checkbox!!");
            }
            res2 = st5.executeQuery(s5);
            jTable6.setModel(DbUtils.resultSetToTableModel(res2));
        } catch (Exception e5) {
            e5.printStackTrace();
            
        }
    }//GEN-LAST:event_jTextFieldIdKeyPressed

    private void jTextFieldIdKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldIdKeyReleased
       try {
            st5 = con.createStatement();
            if (sd1.isSelected()) {
                s5 = "select * from staff_details";
            } else if (gs1.isSelected()) {
                s5 = "select * from agm_gs";
            } else if (ms1.isSelected()) {
                s5 = "select * from agm_ms";
            } else if (af.isSelected()) {
                s5 = "select * from agm_f";
            } else if (om1.isSelected()) {
                s5 = "select * from agm_om";
            }else {
                JOptionPane.showMessageDialog(null, "Data Not Found!Please select any checkbox!!");
            }
            res2 = st5.executeQuery(s5);
            jTable6.setModel(DbUtils.resultSetToTableModel(res2));
        } catch (Exception e5) {
            e5.printStackTrace();
            
        }
    }//GEN-LAST:event_jTextFieldIdKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(View_Page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(View_Page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(View_Page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(View_Page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new View_Page().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Age;
    private javax.swing.JButton ButtonDelete;
    private javax.swing.JButton Clear;
    private javax.swing.JButton Clear1;
    private javax.swing.JButton Clear2;
    private javax.swing.JButton Clear3;
    private javax.swing.JButton Done;
    private javax.swing.JButton Exit;
    private javax.swing.JButton Exit1;
    private javax.swing.JButton Exit2;
    private javax.swing.JButton Exit3;
    private javax.swing.JLabel Gender;
    private javax.swing.JLabel Id;
    private javax.swing.JPanel Insert;
    private javax.swing.JButton InsertButton;
    private javax.swing.JLabel LabelId;
    private javax.swing.JLabel Name;
    private javax.swing.JLabel Name1;
    private javax.swing.JPanel PanelId;
    private javax.swing.JLabel Position;
    private javax.swing.JLabel Salary;
    private javax.swing.JPanel Search;
    private javax.swing.JButton Search1;
    private javax.swing.JButton Search3;
    private javax.swing.JButton Show;
    private javax.swing.JButton Show1;
    private javax.swing.JButton Show2;
    private javax.swing.JButton Show4;
    private javax.swing.JTextField TexName;
    private javax.swing.JTextField TextAge;
    private javax.swing.JTextField TextFieldId;
    private javax.swing.JTextField TextGender;
    private javax.swing.JTextField TextId;
    private javax.swing.JTextField TextPosition;
    private javax.swing.JTextField TextSalary;
    private javax.swing.JTextField TextTime;
    private javax.swing.JLabel Time;
    private javax.swing.JLabel UpAge;
    private javax.swing.JLabel UpGender;
    private javax.swing.JLabel UpId;
    private javax.swing.JLabel UpName;
    private javax.swing.JLabel UpPosition;
    private javax.swing.JLabel UpSalary;
    private javax.swing.JLabel UpTime;
    private javax.swing.JPanel Update;
    private javax.swing.JCheckBox af;
    private javax.swing.JCheckBox af1;
    private javax.swing.JCheckBox f;
    private javax.swing.JCheckBox fSearch;
    private javax.swing.JCheckBox gs;
    private javax.swing.JCheckBox gs1;
    private javax.swing.JCheckBox gs2;
    private javax.swing.JCheckBox gsSearch;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabelId;
    private javax.swing.JLabel jLabelId1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable6;
    private javax.swing.JTable jTable7;
    private javax.swing.JTextField jTextAge;
    private javax.swing.JTextField jTextFieldId;
    private javax.swing.JTextField jTextFieldId1;
    private javax.swing.JTextField jTextGender;
    private javax.swing.JTextField jTextId;
    private javax.swing.JTextField jTextName;
    private javax.swing.JTextField jTextName1;
    private javax.swing.JTextField jTextPosition;
    private javax.swing.JTextField jTextSalary;
    private javax.swing.JTextField jTextTime;
    private javax.swing.JCheckBox ms;
    private javax.swing.JCheckBox ms1;
    private javax.swing.JCheckBox ms2;
    private javax.swing.JCheckBox msSearch;
    private javax.swing.JCheckBox om;
    private javax.swing.JCheckBox om1;
    private javax.swing.JCheckBox om2;
    private javax.swing.JCheckBox omSearch;
    private javax.swing.JCheckBox sd;
    private javax.swing.JCheckBox sd1;
    private javax.swing.JCheckBox sd2;
    private javax.swing.JCheckBox sdSearch;
    // End of variables declaration//GEN-END:variables

}
